# ColdRevive NFR-02 macOS 真机运行包 v1.0

给 **macOS 真机**补一份可归档的证据：验证 `PRIO_DARWIN_BG` 分支在真实 darwin 上是否按读回谓词生效，并做负向对照。

- 源码快照：`v2.4.152`，HEAD `e698d4bef371aeb7b6922c84c2d593051800a466`（见 `SOURCE_INFO.txt`）
- 判据来源：`docs/06-plan/G2-EXIT-RECORD-2026-11-25.md` v1.5 §10「真机收尾清单」
- 本包**不**修改 `g2_claim`，**不**自动宣布 NFR-02 达标 / macOS 已验证 / 三平台达标。
- 所有动作都在 `127.0.0.1`，不连公网 KAD、不连中继、不向外部节点发包。

## 1. 前置条件

1. macOS（Intel 或 Apple Silicon 都行；不提供预编译二进制，在本机构建）。
2. Xcode Command Line Tools：`xcode-select --install`，然后 `xcode-select -p` 能打印路径。
3. Rust（rustup）：`cargo --version` / `rustc --version` 可用。
4. Python 3.8+ 与 `curl`（macOS 通常自带）。
5. 首次构建需要联网拉 crates.io 依赖；之后可在同一台机器重复运行。
6. 本机 `127.0.0.1:19600/19601/19602` 空闲（有旧 `coldrevived` 就先停掉）。

## 2. 运行

```bash
unzip coldrevive-macos-nfr02-runtime-v1.0.zip
cd coldrevive-macos-nfr02-runtime-v1.0
chmod +x run_all.sh
./run_all.sh
```

脚本五个阶段：

1. `cargo test -p cr-engine --lib --locked -- --test-threads=1`  
   其中 `idle_applies_to_the_calling_thread_only` 与 `runtime_worker_task_runs_at_idle_priority` 在 macOS 上会断言 `policy == PRIO_DARWIN_BG`；两条 darwin 判定用例也必须在。
2. `cargo build --bin coldrevived --locked`（debug 构建即可）。
3. 用 `config/daemon-on.json`（`engine.idle_priority=true`）起本地 holder，抓 3 次 `/health` 快照。
4. 用 `config/daemon-off.json`（`engine.idle_priority=false`）起负向对照，再抓 3 次 `/health` 快照。
5. `probes/collect_evidence.py` 汇总成 `results/<运行时间戳>/summary.json`。

## 3. 预期结果

`summary.json` 的 `checks` 里应有四项 `pass` 和一项 `not_verified`：

| 检查 | 期望 |
|---|---|
| `cr-engine unit tests on macOS` | `pass`：退出码 0，5 条关键用例都出现 `... ok` |
| `coldrevived builds on macOS` | `pass`：构建退出码 0、二进制存在 |
| `daemon idle_priority on` | `pass`：3/3 快照 `requested=true, applied>=1, failed=0, unsupported=0`，且 `seed_tasks>=1` |
| `daemon idle_priority off (negative control)` | `pass`：3/3 快照 `requested=false, applied=0, failed=0, unsupported=0` |
| `wake path not downgraded (guard/data-plane)` | `not_verified`：Darwin `getpriority(PRIO_DARWIN_THREAD, 0)` 只能读调用线程，本包没有给唤醒线程加进程内读取器 |

最后一项按 DOC-34 §10 允许如实写「无法逐线程区分」，**不要**用进程级读数或 Linux/Windows 结果顶替。`gate_claim` 固定为 `null`。

## 4. 回传

把整个本次运行目录压缩后发回：

```bash
cd results
zip -r nfr02-macos-<运行时间戳>.zip <运行时间戳>
```

里面应包含：`preflight.txt`、`platform.json`、两份 cargo 日志与 `.exit`、两份 daemon 日志、6 份 `/health` JSON（外加 2 份 probe 快照）、pid/ready 文件、`03-collect.stdout` 与 `summary.json`。

请同时说明：机器型号 / macOS 版本 / 是否 Intel / 运行时是否改过任何配置或阈值。

## 5. 排错

- `xcode-select -p` 报错 → 先装 Command Line Tools；`aws-lc-sys` 这类 C 依赖在 mac 上没有工具链会直接失败。
- `127.0.0.1:19600 已有服务` → 停掉旧进程再跑；脚本故意拒绝，避免把旧进程的 `/health` 当成新证据。
- daemon 提前退出 → 看 `results/<运行时间戳>/daemon-on.log` / `daemon-off.log`。常见原因是端口冲突或 workdir 权限。
- `applied=0` 且 `failed>0` → 真机读回没通过，**不要**手工改成 pass；把日志原样回传。
- 构建或网络失败导致部分阶段没跑 → `summary.json` 中相应项会是 `blocked`/`fail`，同样如实回传。

## 6. 口径提醒

在所有者书面改口径之前，仍然只能说：

- ✅ macOS 分支已实现、判定逻辑有单测、分支经类型检查；
- ✅ 本次真机运行产生了 `/health` 读回证据与负向对照；
- ❌ 不说「NFR-02 三平台达标」「macOS 已验证」；
- ❌ 不把 `not_verified` 的唤醒路径项写成通过；
- ❌ 不改判据、不调阈值、不重抽样后改判。
